// - 실제 카카오맵 표시
// - 업체 좌표 마커
// - 현재 위치 표시
// - 마커 클릭 전달
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../permissions/customer_permission_gateway.dart';
import 'store_discovery_repository.dart';

class KakaoStoreMap extends StatefulWidget {
  const KakaoStoreMap({
    required this.stores,
    required this.currentLocation,
    required this.selectedStoreId,
    required this.onStoreSelected,
    super.key,
  });

  final List<CustomerStore> stores;
  final CustomerLocation? currentLocation;
  final int? selectedStoreId;
  final ValueChanged<CustomerStore> onStoreSelected;

  @override
  State<KakaoStoreMap> createState() => _KakaoStoreMapState();
}

class _KakaoStoreMapState extends State<KakaoStoreMap> {
  static const _kakaoMapKey = String.fromEnvironment(
    'KAKAO_MAP_JS_KEY',
  );

  late final WebViewController _webViewController;

  bool _loading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();

    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFFE7E6DF))
      ..addJavaScriptChannel(
        'StoreMarker',
        onMessageReceived: _handleStoreMarkerMessage,
      )
      ..addJavaScriptChannel(
        'MapReady',
        onMessageReceived: (_) {
          if (!mounted) {
            return;
          }

          setState(() {
            _loading = false;
            _errorMessage = null;
          });
        },
      )
      ..addJavaScriptChannel(
        'MapError',
        onMessageReceived: (message) {
          if (!mounted) {
            return;
          }

          setState(() {
            _loading = false;
            _errorMessage = message.message;
          });
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onWebResourceError: (error) {
            if (!mounted || error.isForMainFrame != true) {
              return;
            }

            setState(() {
              _loading = false;
              _errorMessage = error.description;
            });
          },
        ),
      );

    _loadMap();
  }

  @override
  void didUpdateWidget(covariant KakaoStoreMap oldWidget) {
    super.didUpdateWidget(oldWidget);

    final storesChanged =
        _storeSignature(oldWidget.stores) !=
            _storeSignature(widget.stores);

    final locationChanged =
        oldWidget.currentLocation?.latitude !=
            widget.currentLocation?.latitude ||
            oldWidget.currentLocation?.longitude !=
                widget.currentLocation?.longitude;

    final selectionChanged =
        oldWidget.selectedStoreId != widget.selectedStoreId;

    if (storesChanged || locationChanged || selectionChanged) {
      _loadMap();
    }
  }

  void _handleStoreMarkerMessage(JavaScriptMessage message) {
    final storeId = int.tryParse(message.message);

    if (storeId == null) {
      return;
    }

    for (final store in widget.stores) {
      if (store.storeId == storeId) {
        widget.onStoreSelected(store);
        return;
      }
    }
  }

  Future<void> _loadMap() async {
    if (_kakaoMapKey.isEmpty) {
      if (!mounted) {
        return;
      }

      setState(() {
        _loading = false;
        _errorMessage =
        '카카오맵 JavaScript 키가 없습니다.\n'
            'KAKAO_MAP_JS_KEY를 설정한 뒤 다시 실행해 주세요.';
      });

      return;
    }

    if (mounted) {
      setState(() {
        _loading = true;
        _errorMessage = null;
      });
    }

    await _webViewController.loadHtmlString(
      _buildMapHtml(),
      baseUrl: 'http://localhost/',
    );
  }

  String _buildMapHtml() {
    final stores = widget.stores
        .where(
          (store) =>
      store.latitude != null &&
          store.longitude != null,
    )
        .map(
          (store) => {
        'storeId': store.storeId,
        'name': store.name,
        'storeType': store.storeType,
        'latitude': store.latitude,
        'longitude': store.longitude,
      },
    )
        .toList();

    final storesJson = _safeJson(stores);

    final selectedStoreIdJson = jsonEncode(
      widget.selectedStoreId,
    );

    final currentLocationJson =
    widget.currentLocation == null
        ? 'null'
        : _safeJson({
      'latitude': widget.currentLocation!.latitude,
      'longitude': widget.currentLocation!.longitude,
    });

    final encodedKey = Uri.encodeQueryComponent(
      _kakaoMapKey,
    );

    return '''
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta
    name="viewport"
    content="width=device-width, initial-scale=1.0,
    maximum-scale=1.0, user-scalable=no"
  >

  <style>
    html, body, #map {
      width: 100%;
      height: 100%;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background: #e7e6df;
    }

    .store-label {
      max-width: 160px;
      padding: 8px 12px;
      border: 0;
      border-radius: 999px;
      background: #08110e;
      color: white;
      font-size: 12px;
      font-weight: 800;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      box-shadow: 0 3px 9px rgba(0, 0, 0, 0.28);
    }

    .store-label.selected {
      background: #b7ff00;
      color: #08110e;
      transform: scale(1.06);
    }

    .current-location {
      width: 18px;
      height: 18px;
      border: 4px solid white;
      border-radius: 50%;
      background: #287cff;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.35);
    }
  </style>

  <script>
    window.onerror = function(message) {
      if (window.MapError) {
        MapError.postMessage(String(message));
      }
    };
  </script>

  <script
    src="https://dapi.kakao.com/v2/maps/sdk.js?appkey=$encodedKey&autoload=false">
  </script>
</head>

<body>
  <div id="map"></div>

  <script>
    const stores = $storesJson;
    const selectedStoreId = $selectedStoreIdJson;
    const currentLocation = $currentLocationJson;

    kakao.maps.load(function() {
      let centerLatitude = 37.5665;
      let centerLongitude = 126.9780;

      if (currentLocation !== null) {
        centerLatitude = currentLocation.latitude;
        centerLongitude = currentLocation.longitude;
      } else if (stores.length > 0) {
        centerLatitude = stores[0].latitude;
        centerLongitude = stores[0].longitude;
      }

      const mapContainer = document.getElementById('map');

      const map = new kakao.maps.Map(
        mapContainer,
        {
          center: new kakao.maps.LatLng(
            centerLatitude,
            centerLongitude
          ),
          level: 4
        }
      );

      const bounds = new kakao.maps.LatLngBounds();
      let selectedPosition = null;

      stores.forEach(function(store) {
        const position = new kakao.maps.LatLng(
          store.latitude,
          store.longitude
        );

        bounds.extend(position);

        const button = document.createElement('button');

        button.className =
          store.storeId === selectedStoreId
            ? 'store-label selected'
            : 'store-label';

        button.textContent = store.name;

        button.addEventListener('click', function() {
          StoreMarker.postMessage(
            String(store.storeId)
          );
        });

        new kakao.maps.CustomOverlay({
          map: map,
          position: position,
          content: button,
          yAnchor: 1.15
        });

        if (store.storeId === selectedStoreId) {
          selectedPosition = position;
        }
      });

      if (currentLocation !== null) {
        const currentPosition = new kakao.maps.LatLng(
          currentLocation.latitude,
          currentLocation.longitude
        );

        const currentMarker =
          document.createElement('div');

        currentMarker.className = 'current-location';

        new kakao.maps.CustomOverlay({
          map: map,
          position: currentPosition,
          content: currentMarker,
          yAnchor: 0.5
        });
      }

      if (selectedPosition !== null) {
        map.setCenter(selectedPosition);
        map.setLevel(3);
      } else if (
        currentLocation === null &&
        stores.length > 1
      ) {
        map.setBounds(bounds, 90, 50, 140, 50);
      }

      kakao.maps.event.addListener(
        map,
        'tilesloaded',
        function() {
          MapReady.postMessage('ready');
        }
      );
    });
  </script>
</body>
</html>
''';
  }

  String _safeJson(Object? value) {
    return jsonEncode(value).replaceAll(
      '</script',
      r'<\/script',
    );
  }

  String _storeSignature(
      List<CustomerStore> stores,
      ) {
    return jsonEncode(
      stores
          .map(
            (store) => [
          store.storeId,
          store.name,
          store.storeType,
          store.latitude,
          store.longitude,
        ],
      )
          .toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        WebViewWidget(
          controller: _webViewController,
        ),

        if (_loading)
          const ColoredBox(
            color: Color(0x88FFFFFF),
            child: Center(
              child: CircularProgressIndicator(),
            ),
          ),

        if (_errorMessage != null)
          ColoredBox(
            color: Theme.of(context).colorScheme.surface,
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.map_outlined,
                      size: 52,
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      '카카오맵을 불러오지 못했습니다.',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _errorMessage!,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 18),
                    FilledButton.icon(
                      onPressed: _loadMap,
                      icon: const Icon(
                        Icons.refresh_rounded,
                      ),
                      label: const Text('다시 시도'),
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}